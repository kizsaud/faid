package com.example.pizzeria;

import java.util.ArrayList;

public abstract class Pizza implements Customizable {
    private ArrayList<Topping> toppings;
    private Crust crust;
    private Size size;
    private String [] toppings2;

    private String crust2;
    private String size2;

    public abstract double price();
    protected boolean chicago;
    public Pizza(Crust crust, boolean chicago){
        toppings = new ArrayList<>();
        this.size = Size.medium;
        this.crust = crust;
        this.chicago = chicago;
    }

    public Size getSize() {
        return size;
    }

    public  void setSize(Size size){
        this.size = size;
    }

    public ArrayList<Topping> getToppings(){ return toppings; }

    @Override
    public boolean add(Object obj) {
        if(obj instanceof Topping){
            toppings.add((Topping) obj);
        }
        else if(obj instanceof ArrayList){
            toppings.addAll((ArrayList<Topping>) obj);
        }
        else{
            return false;
        }
        return true;
    }

    @Override
    public boolean remove(Object obj){
        if(obj instanceof Topping){
            toppings.remove((Topping) obj);
        }
        else if(obj instanceof ArrayList){
            toppings.removeAll((ArrayList<Topping>) obj);
        }
        else{
            return false;
        }
        return true;
    }
    public Pizza(Crust style, Size size, ArrayList<Topping> toppings){
        this.toppings=toppings;
        this.crust=style;
        this.size=size;
    }
    public Pizza(Crust style, Size size){
        this.toppings=toppings;
        this.crust=style;
        this.size=size;
    }
    public Pizza(String style, String size){
        this.crust2=style;
        this.size2=size;

    }
    public boolean add() {
        toppings.add(Topping.mushrooms);
        toppings.add(Topping.green_pepper);
        toppings.add(Topping.BBQ_chicken);
        toppings.add(Topping.cheadder);

        return true;
    }

}
