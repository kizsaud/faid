package com.example.pizzeria;

import java.util.ArrayList;
import java.util.List;

public class BBQChicken extends Pizza{
    private static Size size;
    //This is the basic method for pre selected topppings.
    private Crust crust;
  //  private Size size;
    private ArrayList<Topping> toppings = new ArrayList<Topping>();
    public static final double SMALL_PRICE = 13.99;
    public static final double MED_PRICE = 15.99;
    public static final double LARGE_PRICE = 17.99;
    private double price;
    public BBQChicken(Crust crust, boolean isChicago){
        super(crust, isChicago);
        toppings.add(Topping.BBQ_chicken);
        toppings.add(Topping.green_pepper);
        toppings.add(Topping.provolone);
        toppings.add(Topping.cheadder);
    }
    public double price() {
        Size size = getSize();
        if(size == Size.small) return SMALL_PRICE;
        if(size == Size.medium) return MED_PRICE;
        return LARGE_PRICE;
    }
    @Override
    public String toString(){
        StringBuilder str = new StringBuilder("Type: BBQ Chicken (");
        if(chicago){
            str.append("Style: Chicago - Pan),\n ");
        }
        else{
            str.append("NY Style - Thin), ");
        }
        if(toppings != null){
            str.append("Toppings: ");

        }
        //ArrayList<Topping> toppings = getToppings();
        for(Topping t : toppings){
            str.append(t).append(", ");
        }
            str.append("\n");
            str.append("Price: ");
            str.append(getSize().toString().toLowerCase()).append(", $").append(price());
            str.append(".");



        return str.toString();
    }


    public Crust getCrust() {
        return crust;
    }

    public Size getSize() {
        return size;
    }


    public ArrayList<Topping> getToppings() {
        return toppings;
    }

    public double getPrice() {
        return price;
    }
    public static Size setSizer(Size sizer){
        return size=sizer;
    }

    public BBQChicken(String crust,String size){
         super(crust,size);
        if(crust.equals("Pan")){

        }

    }



    @Override
    public boolean add(Object obj) {
        boolean trueFal=false;
      if( toppings.add((Topping) obj)){
          trueFal=true;

      }


        return trueFal;
    }

    @Override
    public boolean remove(Object obj) {
        return false;
    }


}
