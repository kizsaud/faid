package com.example.pizzeria;

public class main22 {
    public static void main(String args[]){




    }
}
