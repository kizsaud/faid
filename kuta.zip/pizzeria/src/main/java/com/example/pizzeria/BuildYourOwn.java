package com.example.pizzeria;

import java.util.ArrayList;

public class BuildYourOwn extends Pizza{
    private static Size size;
    private static double topping;
    //  private Size size;
    private Crust crust;
    private Topping toppings;
    private static ArrayList<Topping> topping2s;
    private static ArrayList<Topping> toppings3;

    //private int topping;
    double price=0;

    public static void setTopping22s( ArrayList<Topping> toppings5) {
        toppings3=toppings5;

    }
    public static void setTopping(){
        topping2s=toppings3;
    }

    public void setTopping2s(ArrayList<Topping> topping2s) {
        this.topping2s = topping2s;
    }

    public BuildYourOwn(Crust crust, boolean isChicago) {
        super(crust, isChicago);
    }

    public static double toppingsize(double toppings){
        return topping=toppings;
    }
    public double getToppingSize(){
        return topping;
    }

    @Override
    public double price() {

        double pricein=0;
        double topping_price = getToppingSize() * 1.59;
        if (size == Size.small) {
            pricein=8.99 + topping_price;
        } else if (size == Size.medium) {
            pricein= 10.99 + topping_price;
        } else if (size == Size.large) {
            pricein= 12.99 + topping_price;
        }
        return pricein;
    }



    public static Size setSizer(Size sizer){

        return size=sizer;
    }

    public Size getSizer(){
        return size;
    }
    public String toString(){
        StringBuilder str = new StringBuilder("Type: Meatzza Chicken (");
        if(chicago){
            str.append("Style: Chicago - Stuffed),\n ");
        }
        else{
            str.append("NY Style - Thin), ");
        }
        if(toppings != null){
            str.append("Toppings: ");

        }
        //ArrayList<Topping> toppings = getToppings();
        for(Topping t : topping2s){
            str.append(t).append(", ");
        }
        str.append("\n");
        str.append("Price: ");
        str.append(getSize().toString().toLowerCase()).append(", $").append(price());
        str.append(".");



        return str.toString();
    }
    public BuildYourOwn(Crust crust, Size size, ArrayList<Topping> toppings,double price) {
        super(crust, size, toppings);
        this.topping2s=toppings;
        this.price=price;
    }
    @Override
    public boolean add(Object obj) {
        if(obj instanceof Topping){
            topping2s.add((Topping) obj);
        }
        else if(obj instanceof ArrayList){
            topping2s.addAll((ArrayList<Topping>) obj);
        }
        else{
            return false;
        }
        return true;
    }

    @Override
    public boolean remove(Object obj){
        if(obj instanceof Topping){
            topping2s.remove((Topping) obj);
        }
        else if(obj instanceof ArrayList){
            topping2s.removeAll((ArrayList<Topping>) obj);
        }
        else{
            return false;
        }
        return true;
    }
    public ArrayList<Topping> getToppings(){
        return topping2s;
    }

    public double getPrice() {
        return price;
    }







}
