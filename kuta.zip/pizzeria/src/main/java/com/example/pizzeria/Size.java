package com.example.pizzeria;

public enum Size {
    small,large,medium


}
