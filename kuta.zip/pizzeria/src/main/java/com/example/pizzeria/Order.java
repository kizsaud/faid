package com.example.pizzeria;

import java.util.ArrayList;

public class Order implements Customizable{
    private int orderNumber=0;
    boolean isRe;
    private ArrayList <Object> A = new ArrayList<Object>();
    public Order(){

    }

    public ArrayList<Object> getA() {
        return A;
    }

    @Override
    public boolean add(Object obj) {
        boolean sucfail=false;
        if(obj instanceof Pizza){
            A.add(obj);
            sucfail=true;
        }else {
            sucfail=false;
        }return sucfail;
    }
    void setOrderNumber(){
        orderNumber++;
        }

    @Override
    public boolean remove(Object obj) {
        boolean sucfail = false;
        if (obj instanceof Pizza) {
            A.remove( obj);
            sucfail = true;
        } else {
            sucfail = false;
        }
        return sucfail;
    }
}
