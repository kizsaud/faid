package com.example.pizzeria;

public enum Topping {
    Sausage, pepperoni, BBQ_chicken, green_pepper,beef, ham, pineapple,provolone,cheadder, red_pepper, onion,mushrooms,spinach, feta_cheese;

    double price=1.49;
    private Topping(){
        this.price=1.49;
    }


}
