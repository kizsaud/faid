package com.example.pizzeria.test;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class BuildYourOwnTest {

    @Test
    public void test(){
        assertEquals(true, true);
    }
}